import './index.css'

import {Component} from 'react'

class LightDarkMode extends Component {
  state = {light: true}

  onChange = () => {
    this.setState(prevState => ({light: !prevState.light}))
  }

  buttonText = () => {
    const {light} = this.state

    return light ? 'Light Mode' : 'Dark Mode'
  }

  color = () => {
    const {light} = this.state

    return light ? 'light-background' : 'dark-background'
  }

  render() {
    const buttonText = this.buttonText()
    const color = this.color()

    return (
      <div className={`container ${color}`}>
        <h1 className="heading">Click To Change Mode</h1>
        <button className="button" type="button" onClick={this.onChange}>
          {buttonText}
        </button>
      </div>
    )
  }
}
export default LightDarkMode
